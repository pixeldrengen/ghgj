/*
 * Decompiled with CFR 0_118.
 */
package javax.annotation.meta;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Documented
@Target(value={ElementType.ANNOTATION_TYPE})
public @interface TypeQualifierNickname {
}

