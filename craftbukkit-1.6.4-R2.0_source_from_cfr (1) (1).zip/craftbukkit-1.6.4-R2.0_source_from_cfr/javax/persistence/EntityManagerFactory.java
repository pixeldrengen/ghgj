/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence;

import java.util.Map;
import javax.persistence.EntityManager;

public interface EntityManagerFactory {
    public EntityManager createEntityManager();

    public EntityManager createEntityManager(Map var1);

    public void close();

    public boolean isOpen();
}

