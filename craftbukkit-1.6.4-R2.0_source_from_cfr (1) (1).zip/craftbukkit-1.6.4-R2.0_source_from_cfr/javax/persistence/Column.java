/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.METHOD, ElementType.FIELD})
@Retention(value=RetentionPolicy.RUNTIME)
public @interface Column {
    public String name() default "";

    public boolean unique() default 0;

    public boolean nullable() default 1;

    public boolean insertable() default 1;

    public boolean updatable() default 1;

    public String columnDefinition() default "";

    public String table() default "";

    public int length() default 255;

    public int precision() default 0;

    public int scale() default 0;
}

