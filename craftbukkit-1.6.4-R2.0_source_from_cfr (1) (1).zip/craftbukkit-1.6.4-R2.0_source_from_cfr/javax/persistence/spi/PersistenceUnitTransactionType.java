/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence.spi;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public enum PersistenceUnitTransactionType {
    JTA,
    RESOURCE_LOCAL;
    

    private PersistenceUnitTransactionType() {
    }
}

