/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence.spi;

import java.util.Map;
import javax.persistence.EntityManagerFactory;
import javax.persistence.spi.PersistenceUnitInfo;

public interface PersistenceProvider {
    public EntityManagerFactory createEntityManagerFactory(String var1, Map var2);

    public EntityManagerFactory createContainerEntityManagerFactory(PersistenceUnitInfo var1, Map var2);
}

