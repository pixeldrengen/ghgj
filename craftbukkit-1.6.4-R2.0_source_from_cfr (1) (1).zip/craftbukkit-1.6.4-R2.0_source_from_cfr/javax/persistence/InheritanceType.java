/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public enum InheritanceType {
    SINGLE_TABLE,
    TABLE_PER_CLASS,
    JOINED;
    

    private InheritanceType() {
    }
}

