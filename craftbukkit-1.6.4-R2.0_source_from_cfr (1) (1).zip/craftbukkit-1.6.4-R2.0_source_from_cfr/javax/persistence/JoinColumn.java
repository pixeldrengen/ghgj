/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(value=RetentionPolicy.RUNTIME)
public @interface JoinColumn {
    public String name() default "";

    public String referencedColumnName() default "";

    public boolean unique() default 0;

    public boolean nullable() default 1;

    public boolean insertable() default 1;

    public boolean updatable() default 1;

    public String columnDefinition() default "";

    public String table() default "";
}

