/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.FlushModeType;
import javax.persistence.TemporalType;

public interface Query {
    public List getResultList();

    public Object getSingleResult();

    public int executeUpdate();

    public Query setMaxResults(int var1);

    public Query setFirstResult(int var1);

    public Query setHint(String var1, Object var2);

    public Query setParameter(String var1, Object var2);

    public Query setParameter(String var1, Date var2, TemporalType var3);

    public Query setParameter(String var1, Calendar var2, TemporalType var3);

    public Query setParameter(int var1, Object var2);

    public Query setParameter(int var1, Date var2, TemporalType var3);

    public Query setParameter(int var1, Calendar var2, TemporalType var3);

    public Query setFlushMode(FlushModeType var1);
}

