/*
 * Decompiled with CFR 0_118.
 */
package javax.persistence;

import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Query;

public interface EntityManager {
    public void persist(Object var1);

    public <T> T merge(T var1);

    public void remove(Object var1);

    public <T> T find(Class<T> var1, Object var2);

    public <T> T getReference(Class<T> var1, Object var2);

    public void flush();

    public void setFlushMode(FlushModeType var1);

    public FlushModeType getFlushMode();

    public void lock(Object var1, LockModeType var2);

    public void refresh(Object var1);

    public void clear();

    public boolean contains(Object var1);

    public Query createQuery(String var1);

    public Query createNamedQuery(String var1);

    public Query createNativeQuery(String var1);

    public Query createNativeQuery(String var1, Class var2);

    public Query createNativeQuery(String var1, String var2);

    public void joinTransaction();

    public Object getDelegate();

    public void close();

    public boolean isOpen();

    public EntityTransaction getTransaction();
}

