/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class SortByClause {
    public static final String NULLSHIGH = "nullshigh";
    public static final String NULLSLOW = "nullslow";
    public static final String ASC = "asc";
    public static final String DESC = "desc";
    private List<Property> properties = new ArrayList<Property>();

    public int size() {
        return this.properties.size();
    }

    public List<Property> getProperties() {
        return this.properties;
    }

    public void add(Property p) {
        this.properties.add(p);
    }

    public static class Property
    implements Serializable {
        private static final long serialVersionUID = 7588760362420690963L;
        private final String name;
        private final boolean ascending;
        private final Boolean nullsHigh;

        public Property(String name, boolean ascending, Boolean nullsHigh) {
            this.name = name;
            this.ascending = ascending;
            this.nullsHigh = nullsHigh;
        }

        public String toString() {
            return this.name + " asc:" + this.ascending;
        }

        public String getName() {
            return this.name;
        }

        public boolean isAscending() {
            return this.ascending;
        }

        public Boolean getNullsHigh() {
            return this.nullsHigh;
        }
    }

}

