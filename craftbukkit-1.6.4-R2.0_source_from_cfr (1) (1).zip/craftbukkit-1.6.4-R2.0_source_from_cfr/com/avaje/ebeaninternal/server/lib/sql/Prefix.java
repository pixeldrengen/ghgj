/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.lib.sql;

import java.util.Random;
import java.util.logging.Logger;

public class Prefix {
    private static final Logger logger = Logger.getLogger(Prefix.class.getName());
    private static final int[] oa = new int[]{50, 12, 4, 6, 8, 10, 7, 23, 45, 23, 6, 9, 12, 2, 8, 34};

    public static String getProp(String prop) {
        String v = Prefix.dec(prop);
        int p = v.indexOf(":");
        String r = v.substring(1, p);
        return r;
    }

    public static void main(String[] args) {
        String m = Prefix.e(args[0]);
        logger.info("[" + m + "]");
        String o = Prefix.getProp(m);
        logger.info("[" + o + "]");
    }

    public static String e(String msg) {
        msg = Prefix.elen(msg, 40);
        return Prefix.enc(msg);
    }

    public static byte az(byte c, int offset) {
        int z = c + offset;
        if (z > 122) {
            z = z - 122 + 48 - 1;
        }
        return (byte)z;
    }

    public static byte bz(byte c, int offset) {
        int z = c - offset;
        if (z < 48) {
            z = z + 122 - 48 + 1;
        }
        return (byte)z;
    }

    public static String enc(String msg) {
        byte[] msgbytes = msg.getBytes();
        byte[] encbytes = new byte[msgbytes.length + 1];
        Random r = new Random();
        int key = r.nextInt(70);
        char k = (char)(key + 48);
        encbytes[0] = Prefix.az((byte)k, oa[0]);
        int ios = key;
        for (int i = 1; i < msgbytes.length + 1; ++i) {
            encbytes[i] = Prefix.az(msgbytes[i - 1], oa[(i + ios) % oa.length]);
        }
        return new String(encbytes);
    }

    public static String dec(String msg) {
        byte[] msgbytes = msg.getBytes();
        byte[] encbytes = new byte[msgbytes.length];
        encbytes[0] = Prefix.bz(msgbytes[0], oa[0]);
        byte key = encbytes[0];
        int ios = key - 48;
        for (int i = 1; i < msgbytes.length; ++i) {
            encbytes[i] = Prefix.bz(msgbytes[i], oa[(i + ios) % oa.length]);
        }
        return new String(encbytes);
    }

    public static String elen(String msg, int len) {
        Random r = new Random();
        if (msg.length() < len) {
            int max = len - msg.length();
            StringBuilder sb = new StringBuilder();
            sb.append(msg).append(":");
            for (int i = 1; i < max; ++i) {
                int bc = r.nextInt(74);
                sb.append(Character.toString((char)(bc + 48)));
            }
            return sb.toString();
        }
        return msg;
    }
}

