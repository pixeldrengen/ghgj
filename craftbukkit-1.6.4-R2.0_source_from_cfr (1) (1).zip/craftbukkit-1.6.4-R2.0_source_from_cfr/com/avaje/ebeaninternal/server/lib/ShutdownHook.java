/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.lib;

import com.avaje.ebeaninternal.server.lib.ShutdownManager;

class ShutdownHook
extends Thread {
    ShutdownHook() {
    }

    public void run() {
        ShutdownManager.shutdown();
    }
}

