/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.lib.util;

public class StringParsingException
extends RuntimeException {
    static final long serialVersionUID = -3070423471260426402L;

    public StringParsingException(String message) {
        super(message);
    }
}

