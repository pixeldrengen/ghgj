/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.lib.util;

import com.avaje.ebeaninternal.server.lib.util.MailEvent;

public interface MailListener {
    public void handleEvent(MailEvent var1);
}

