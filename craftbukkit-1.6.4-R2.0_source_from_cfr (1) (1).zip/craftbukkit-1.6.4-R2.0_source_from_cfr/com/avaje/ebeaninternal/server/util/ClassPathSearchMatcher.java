/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.util;

public interface ClassPathSearchMatcher {
    public boolean isMatch(Class<?> var1);
}

