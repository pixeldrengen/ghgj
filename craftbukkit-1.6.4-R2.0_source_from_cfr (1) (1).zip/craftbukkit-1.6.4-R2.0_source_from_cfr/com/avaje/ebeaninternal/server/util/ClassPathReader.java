/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.util;

public interface ClassPathReader {
    public Object[] readPath(ClassLoader var1);
}

