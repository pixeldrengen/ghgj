/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.jmx;

public interface MAdminAutofetchMBean {
    public boolean isProfiling();

    public void setProfiling(boolean var1);

    public boolean isQueryTuning();

    public void setQueryTuning(boolean var1);

    public String getMode();

    public String getModeOptions();

    public void setMode(String var1);

    public int getProfilingBase();

    public void setProfilingBase(int var1);

    public double getProfilingRate();

    public void setProfilingRate(double var1);

    public int getProfilingMin();

    public void setProfilingMin(int var1);

    public String collectUsageViaGC();

    public String updateTunedQueryInfo();

    public int clearTunedQueryInfo();

    public int clearProfilingInfo();

    public int getTotalTunedQueryCount();

    public int getTotalTunedQuerySize();

    public int getTotalProfileSize();
}

