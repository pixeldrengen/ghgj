/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.deploy;

import com.avaje.ebeaninternal.server.deploy.InheritInfo;

public interface InheritInfoVisitor {
    public void visit(InheritInfo var1);
}

