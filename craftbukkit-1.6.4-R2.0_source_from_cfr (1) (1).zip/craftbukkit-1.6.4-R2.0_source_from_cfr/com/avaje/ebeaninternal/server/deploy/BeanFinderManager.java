/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.deploy;

import com.avaje.ebean.event.BeanFinder;
import java.util.List;

public interface BeanFinderManager {
    public int getRegisterCount();

    public int createBeanFinders(List<Class<?>> var1);

    public <T> BeanFinder<T> getBeanFinder(Class<T> var1);
}

