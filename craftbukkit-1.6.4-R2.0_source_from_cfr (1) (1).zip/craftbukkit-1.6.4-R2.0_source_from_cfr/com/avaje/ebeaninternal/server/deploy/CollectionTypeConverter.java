/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.deploy;

public interface CollectionTypeConverter {
    public Object toUnderlying(Object var1);

    public Object toWrapped(Object var1);
}

