/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.querydefn;

import com.avaje.ebean.EbeanServer;
import com.avaje.ebean.SqlFutureList;
import com.avaje.ebean.SqlQuery;
import com.avaje.ebean.SqlQueryListener;
import com.avaje.ebean.SqlRow;
import com.avaje.ebean.Transaction;
import com.avaje.ebeaninternal.api.BindParams;
import com.avaje.ebeaninternal.api.SpiSqlQuery;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.persistence.PersistenceException;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class DefaultRelationalQuery
implements SpiSqlQuery {
    private static final long serialVersionUID = -1098305779779591068L;
    private transient EbeanServer server;
    private transient SqlQueryListener queryListener;
    private String query;
    private int firstRow;
    private int maxRows;
    private int timeout;
    private boolean futureFetch;
    private boolean cancelled;
    private transient PreparedStatement pstmt;
    private int backgroundFetchAfter;
    private int bufferFetchSizeHint;
    private String mapKey;
    private BindParams bindParams = new BindParams();

    public DefaultRelationalQuery(EbeanServer server, String query) {
        this.server = server;
        this.query = query;
    }

    public DefaultRelationalQuery setQuery(String query) {
        this.query = query;
        return this;
    }

    @Override
    public List<SqlRow> findList() {
        return this.server.findList(this, null);
    }

    @Override
    public Set<SqlRow> findSet() {
        return this.server.findSet(this, null);
    }

    @Override
    public Map<?, SqlRow> findMap() {
        return this.server.findMap(this, null);
    }

    @Override
    public SqlRow findUnique() {
        return this.server.findUnique(this, null);
    }

    @Override
    public SqlFutureList findFutureList() {
        return this.server.findFutureList(this, null);
    }

    @Override
    public DefaultRelationalQuery setParameter(int position, Object value) {
        this.bindParams.setParameter(position, value);
        return this;
    }

    @Override
    public DefaultRelationalQuery setParameter(String paramName, Object value) {
        this.bindParams.setParameter(paramName, value);
        return this;
    }

    @Override
    public SqlQueryListener getListener() {
        return this.queryListener;
    }

    @Override
    public DefaultRelationalQuery setListener(SqlQueryListener queryListener) {
        this.queryListener = queryListener;
        return this;
    }

    public String toString() {
        return "SqlQuery [" + this.query + "]";
    }

    @Override
    public int getFirstRow() {
        return this.firstRow;
    }

    @Override
    public DefaultRelationalQuery setFirstRow(int firstRow) {
        this.firstRow = firstRow;
        return this;
    }

    @Override
    public int getMaxRows() {
        return this.maxRows;
    }

    @Override
    public DefaultRelationalQuery setMaxRows(int maxRows) {
        this.maxRows = maxRows;
        return this;
    }

    @Override
    public String getMapKey() {
        return this.mapKey;
    }

    @Override
    public DefaultRelationalQuery setMapKey(String mapKey) {
        this.mapKey = mapKey;
        return this;
    }

    @Override
    public int getBackgroundFetchAfter() {
        return this.backgroundFetchAfter;
    }

    @Override
    public DefaultRelationalQuery setBackgroundFetchAfter(int backgroundFetchAfter) {
        this.backgroundFetchAfter = backgroundFetchAfter;
        return this;
    }

    @Override
    public int getTimeout() {
        return this.timeout;
    }

    @Override
    public DefaultRelationalQuery setTimeout(int secs) {
        this.timeout = secs;
        return this;
    }

    @Override
    public BindParams getBindParams() {
        return this.bindParams;
    }

    @Override
    public DefaultRelationalQuery setBufferFetchSizeHint(int bufferFetchSizeHint) {
        this.bufferFetchSizeHint = bufferFetchSizeHint;
        return this;
    }

    @Override
    public int getBufferFetchSizeHint() {
        return this.bufferFetchSizeHint;
    }

    @Override
    public String getQuery() {
        return this.query;
    }

    @Override
    public boolean isFutureFetch() {
        return this.futureFetch;
    }

    @Override
    public void setFutureFetch(boolean futureFetch) {
        this.futureFetch = futureFetch;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void setPreparedStatement(PreparedStatement pstmt) {
        DefaultRelationalQuery defaultRelationalQuery = this;
        synchronized (defaultRelationalQuery) {
            this.pstmt = pstmt;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void cancel() {
        DefaultRelationalQuery defaultRelationalQuery = this;
        synchronized (defaultRelationalQuery) {
            this.cancelled = true;
            if (this.pstmt != null) {
                try {
                    this.pstmt.cancel();
                }
                catch (SQLException e) {
                    String msg = "Error cancelling query";
                    throw new PersistenceException(msg, e);
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public boolean isCancelled() {
        DefaultRelationalQuery defaultRelationalQuery = this;
        synchronized (defaultRelationalQuery) {
            return this.cancelled;
        }
    }
}

