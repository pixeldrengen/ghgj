/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.cache;

import com.avaje.ebean.EbeanServer;
import com.avaje.ebean.cache.ServerCache;
import com.avaje.ebean.cache.ServerCacheFactory;
import com.avaje.ebean.cache.ServerCacheOptions;
import com.avaje.ebeaninternal.server.cache.DefaultServerCache;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class DefaultServerCacheFactory
implements ServerCacheFactory {
    private EbeanServer ebeanServer;

    @Override
    public void init(EbeanServer ebeanServer) {
        this.ebeanServer = ebeanServer;
    }

    @Override
    public ServerCache createCache(Class<?> beanType, ServerCacheOptions cacheOptions) {
        DefaultServerCache cache = new DefaultServerCache("Bean:" + beanType, cacheOptions);
        cache.init(this.ebeanServer);
        return cache;
    }
}

