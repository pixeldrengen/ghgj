/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.persist.dml;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public enum DmlMode {
    INSERT,
    UPDATE,
    WHERE;
    

    private DmlMode() {
    }
}

