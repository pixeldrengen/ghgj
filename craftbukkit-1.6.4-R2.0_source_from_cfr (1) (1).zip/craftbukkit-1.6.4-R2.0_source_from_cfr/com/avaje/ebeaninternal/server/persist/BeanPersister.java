/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.persist;

import com.avaje.ebeaninternal.server.core.PersistRequestBean;
import javax.persistence.PersistenceException;

public interface BeanPersister {
    public void insert(PersistRequestBean<?> var1) throws PersistenceException;

    public void update(PersistRequestBean<?> var1) throws PersistenceException;

    public void delete(PersistRequestBean<?> var1) throws PersistenceException;
}

