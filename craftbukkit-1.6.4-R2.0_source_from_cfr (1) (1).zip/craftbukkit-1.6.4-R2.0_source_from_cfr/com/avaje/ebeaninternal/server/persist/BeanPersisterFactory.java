/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.persist;

import com.avaje.ebeaninternal.server.deploy.BeanDescriptor;
import com.avaje.ebeaninternal.server.persist.BeanPersister;

public interface BeanPersisterFactory {
    public BeanPersister create(BeanDescriptor<?> var1);
}

