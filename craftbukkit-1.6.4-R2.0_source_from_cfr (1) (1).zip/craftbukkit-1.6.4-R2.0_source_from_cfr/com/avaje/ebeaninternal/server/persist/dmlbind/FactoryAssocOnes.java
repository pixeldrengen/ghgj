/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.persist.dmlbind;

import com.avaje.ebeaninternal.server.deploy.BeanDescriptor;
import com.avaje.ebeaninternal.server.deploy.BeanPropertyAssocOne;
import com.avaje.ebeaninternal.server.persist.dml.DmlMode;
import com.avaje.ebeaninternal.server.persist.dmlbind.Bindable;
import com.avaje.ebeaninternal.server.persist.dmlbind.BindableAssocOne;
import java.util.List;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class FactoryAssocOnes {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public List<Bindable> create(List<Bindable> list, BeanDescriptor<?> desc, DmlMode mode) {
        ones = desc.propertiesOneImported();
        i = 0;
        while (i < ones.length) {
            if (ones[i].isImportedPrimaryKey()) ** GOTO lbl14
            switch (1.$SwitchMap$com$avaje$ebeaninternal$server$persist$dml$DmlMode[mode.ordinal()]) {
                case 1: {
                    break;
                }
                case 2: {
                    if (ones[i].isInsertable()) break;
                    ** break;
                }
                case 3: {
                    if (!ones[i].isUpdateable()) ** GOTO lbl14
                }
            }
            list.add(new BindableAssocOne(ones[i]));
lbl14: // 4 sources:
            ++i;
        }
        return list;
    }

    static class 1 {
        static final /* synthetic */ int[] $SwitchMap$com$avaje$ebeaninternal$server$persist$dml$DmlMode;

        static {
            $SwitchMap$com$avaje$ebeaninternal$server$persist$dml$DmlMode = new int[DmlMode.values().length];
            try {
                1.$SwitchMap$com$avaje$ebeaninternal$server$persist$dml$DmlMode[DmlMode.WHERE.ordinal()] = 1;
            }
            catch (NoSuchFieldError ex) {
                // empty catch block
            }
            try {
                1.$SwitchMap$com$avaje$ebeaninternal$server$persist$dml$DmlMode[DmlMode.INSERT.ordinal()] = 2;
            }
            catch (NoSuchFieldError ex) {
                // empty catch block
            }
            try {
                1.$SwitchMap$com$avaje$ebeaninternal$server$persist$dml$DmlMode[DmlMode.UPDATE.ordinal()] = 3;
            }
            catch (NoSuchFieldError ex) {
                // empty catch block
            }
        }
    }

}

