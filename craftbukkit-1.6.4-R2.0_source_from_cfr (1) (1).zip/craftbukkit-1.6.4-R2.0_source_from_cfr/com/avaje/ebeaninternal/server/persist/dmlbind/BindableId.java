/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.persist.dmlbind;

import com.avaje.ebeaninternal.server.core.PersistRequestBean;
import com.avaje.ebeaninternal.server.persist.dmlbind.Bindable;

public interface BindableId
extends Bindable {
    public boolean isConcatenated();

    public String getIdentityColumn();

    public boolean deriveConcatenatedId(PersistRequestBean<?> var1);
}

