/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.el;

import java.util.Comparator;

public interface ElComparator<T>
extends Comparator<T> {
    @Override
    public int compare(T var1, T var2);

    public int compareValue(Object var1, T var2);
}

