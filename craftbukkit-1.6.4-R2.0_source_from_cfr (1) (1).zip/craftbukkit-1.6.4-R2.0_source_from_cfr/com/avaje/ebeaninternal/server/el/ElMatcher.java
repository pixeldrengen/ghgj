/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.el;

public interface ElMatcher<T> {
    public boolean isMatch(T var1);
}

