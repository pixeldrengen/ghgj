/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.el;

public interface ElSetValue {
    public void elSetValue(Object var1, Object var2);
}

