/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.text.json;

public interface WriteJsonBuffer {
    public WriteJsonBuffer append(String var1);
}

