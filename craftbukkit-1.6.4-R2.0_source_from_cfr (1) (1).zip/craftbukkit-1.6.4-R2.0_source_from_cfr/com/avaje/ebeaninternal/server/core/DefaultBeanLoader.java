/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.core;

import com.avaje.ebean.AdminLogging;
import com.avaje.ebean.ExpressionList;
import com.avaje.ebean.Query;
import com.avaje.ebean.Transaction;
import com.avaje.ebean.bean.BeanCollection;
import com.avaje.ebean.bean.EntityBean;
import com.avaje.ebean.bean.EntityBeanIntercept;
import com.avaje.ebean.bean.ObjectGraphNode;
import com.avaje.ebean.bean.PersistenceContext;
import com.avaje.ebeaninternal.api.LoadBeanContext;
import com.avaje.ebeaninternal.api.LoadBeanRequest;
import com.avaje.ebeaninternal.api.LoadManyContext;
import com.avaje.ebeaninternal.api.LoadManyRequest;
import com.avaje.ebeaninternal.api.SpiQuery;
import com.avaje.ebeaninternal.server.core.DebugLazyLoad;
import com.avaje.ebeaninternal.server.core.DefaultServer;
import com.avaje.ebeaninternal.server.deploy.BeanDescriptor;
import com.avaje.ebeaninternal.server.deploy.BeanProperty;
import com.avaje.ebeaninternal.server.deploy.BeanPropertyAssocMany;
import com.avaje.ebeaninternal.server.deploy.ManyType;
import com.avaje.ebeaninternal.server.deploy.id.IdBinder;
import com.avaje.ebeaninternal.server.transaction.DefaultPersistenceContext;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.PersistenceException;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class DefaultBeanLoader {
    private static final Logger logger = Logger.getLogger(DefaultBeanLoader.class.getName());
    private final DebugLazyLoad debugLazyLoad;
    private final DefaultServer server;

    protected DefaultBeanLoader(DefaultServer server, DebugLazyLoad debugLazyLoad) {
        this.server = server;
        this.debugLazyLoad = debugLazyLoad;
    }

    private int getBatchSize(int batchListSize, int requestedBatchSize) {
        if (batchListSize == requestedBatchSize) {
            return batchListSize;
        }
        if (batchListSize == 1) {
            return 1;
        }
        if (requestedBatchSize <= 5) {
            return 5;
        }
        if (batchListSize <= 10 || requestedBatchSize <= 10) {
            return 10;
        }
        if (batchListSize <= 20 || requestedBatchSize <= 20) {
            return 20;
        }
        if (batchListSize <= 50) {
            return 50;
        }
        return requestedBatchSize;
    }

    public void refreshMany(Object parentBean, String propertyName) {
        this.refreshMany(parentBean, propertyName, null);
    }

    public void loadMany(LoadManyRequest loadRequest) {
        List batch = loadRequest.getBatch();
        int batchSize = this.getBatchSize(batch.size(), loadRequest.getBatchSize());
        LoadManyContext ctx = loadRequest.getLoadContext();
        BeanPropertyAssocMany many = ctx.getBeanProperty();
        PersistenceContext pc = ctx.getPersistenceContext();
        ArrayList<Object> idList = new ArrayList<Object>(batchSize);
        for (int i = 0; i < batch.size(); ++i) {
            BeanCollection bc = batch.get(i);
            Object ownerBean = bc.getOwnerBean();
            Object id = many.getParentId(ownerBean);
            idList.add(id);
        }
        int extraIds = batchSize - batch.size();
        if (extraIds > 0) {
            Object firstId = idList.get(0);
            for (int i2 = 0; i2 < extraIds; ++i2) {
                idList.add(firstId);
            }
        }
        BeanDescriptor desc = ctx.getBeanDescriptor();
        String idProperty = desc.getIdBinder().getIdProperty();
        SpiQuery query = (SpiQuery)this.server.createQuery(desc.getBeanType());
        query.setMode(SpiQuery.Mode.LAZYLOAD_MANY);
        query.setLazyLoadManyPath(many.getName());
        query.setPersistenceContext(pc);
        query.select(idProperty);
        query.fetch(many.getName());
        if (idList.size() == 1) {
            query.where().idEq(idList.get(0));
        } else {
            query.where().idIn(idList);
        }
        String mode = loadRequest.isLazy() ? "+lazy" : "+query";
        query.setLoadDescription(mode, loadRequest.getDescription());
        ctx.configureQuery(query);
        if (loadRequest.isOnlyIds()) {
            query.fetch(many.getName(), many.getTargetIdProperty());
        }
        this.server.findList(query, loadRequest.getTransaction());
        for (int i3 = 0; i3 < batch.size(); ++i3) {
            if (!batch.get(i3).checkEmptyLazyLoad() || !logger.isLoggable(Level.FINE)) continue;
            logger.fine("BeanCollection after load was empty. Owner:" + batch.get(i3).getOwnerBean());
        }
    }

    public void loadMany(BeanCollection<?> bc, LoadManyContext ctx, boolean onlyIds) {
        Object parentBean = bc.getOwnerBean();
        String propertyName = bc.getPropertyName();
        ObjectGraphNode node = ctx == null ? null : ctx.getObjectGraphNode();
        this.loadManyInternal(parentBean, propertyName, null, false, node, onlyIds);
        if (this.server.getAdminLogging().isDebugLazyLoad()) {
            Class cls = parentBean.getClass();
            BeanDescriptor desc = this.server.getBeanDescriptor(cls);
            BeanPropertyAssocMany many = (BeanPropertyAssocMany)desc.getBeanProperty(propertyName);
            StackTraceElement cause = this.debugLazyLoad.getStackTraceElement(cls);
            String msg = "debug.lazyLoad " + many.getManyType() + " [" + desc + "][" + propertyName + "]";
            if (cause != null) {
                msg = msg + " at: " + cause;
            }
            System.err.println(msg);
        }
    }

    public void refreshMany(Object parentBean, String propertyName, Transaction t) {
        this.loadManyInternal(parentBean, propertyName, t, true, null, false);
    }

    private void loadManyInternal(Object parentBean, String propertyName, Transaction t, boolean refresh, ObjectGraphNode node, boolean onlyIds) {
        BeanDescriptor parentDesc;
        BeanPropertyAssocMany many;
        Object currentValue;
        boolean vanilla = !(parentBean instanceof EntityBean);
        EntityBeanIntercept ebi = null;
        PersistenceContext pc = null;
        BeanCollection beanCollection = null;
        ExpressionList filterMany = null;
        if (!vanilla) {
            ebi = ((EntityBean)parentBean)._ebean_getIntercept();
            pc = ebi.getPersistenceContext();
        }
        if ((currentValue = (many = (BeanPropertyAssocMany)(parentDesc = this.server.getBeanDescriptor(parentBean.getClass())).getBeanProperty(propertyName)).getValueUnderlying(parentBean)) instanceof BeanCollection) {
            beanCollection = (BeanCollection)currentValue;
            filterMany = beanCollection.getFilterMany();
        }
        Object parentId = parentDesc.getId(parentBean);
        if (pc == null) {
            pc = new DefaultPersistenceContext();
            pc.put(parentId, parentBean);
        }
        SpiQuery query = (SpiQuery)this.server.createQuery(parentDesc.getBeanType());
        if (refresh) {
            Object emptyCollection = many.createEmpty(vanilla);
            many.setValue(parentBean, emptyCollection);
            if (!vanilla && ebi != null && ebi.isSharedInstance()) {
                ((BeanCollection)emptyCollection).setSharedInstance();
            }
            query.setLoadDescription("+refresh", null);
        } else {
            query.setLoadDescription("+lazy", null);
        }
        if (node != null) {
            query.setParentNode(node);
        }
        String idProperty = parentDesc.getIdBinder().getIdProperty();
        query.select(idProperty);
        if (onlyIds) {
            query.fetch(many.getName(), many.getTargetIdProperty());
        } else {
            query.fetch(many.getName());
        }
        if (filterMany != null) {
            query.setFilterMany(many.getName(), filterMany);
        }
        query.where().idEq(parentId);
        query.setMode(SpiQuery.Mode.LAZYLOAD_MANY);
        query.setLazyLoadManyPath(many.getName());
        query.setPersistenceContext(pc);
        query.setVanillaMode(vanilla);
        if (ebi != null) {
            if (ebi.isSharedInstance()) {
                query.setSharedInstance();
            } else if (ebi.isReadOnly()) {
                query.setReadOnly(true);
            }
        }
        this.server.findUnique(query, t);
        if (beanCollection != null && beanCollection.checkEmptyLazyLoad() && logger.isLoggable(Level.FINE)) {
            logger.fine("BeanCollection after load was empty. Owner:" + beanCollection.getOwnerBean());
        }
    }

    public void loadBean(LoadBeanRequest loadRequest) {
        List<EntityBeanIntercept> batch = loadRequest.getBatch();
        if (batch.size() == 0) {
            throw new RuntimeException("Nothing in batch?");
        }
        int batchSize = this.getBatchSize(batch.size(), loadRequest.getBatchSize());
        LoadBeanContext ctx = loadRequest.getLoadContext();
        BeanDescriptor desc = ctx.getBeanDescriptor();
        Class beanType = desc.getBeanType();
        EntityBeanIntercept[] ebis = batch.toArray(new EntityBeanIntercept[batch.size()]);
        ArrayList<Object> idList = new ArrayList<Object>(batchSize);
        for (int i = 0; i < batch.size(); ++i) {
            EntityBean bean = batch.get(i).getOwner();
            Object id = desc.getId(bean);
            idList.add(id);
        }
        int extraIds = batchSize - batch.size();
        if (extraIds > 0) {
            Object firstId = idList.get(0);
            for (int i2 = 0; i2 < extraIds; ++i2) {
                idList.add(firstId);
            }
        }
        PersistenceContext persistenceContext = ctx.getPersistenceContext();
        for (int i3 = 0; i3 < ebis.length; ++i3) {
            Object parentBean = ebis[i3].getParentBean();
            if (parentBean == null) continue;
            BeanDescriptor parentDesc = this.server.getBeanDescriptor(parentBean.getClass());
            Object parentId = parentDesc.getId(parentBean);
            persistenceContext.put(parentId, parentBean);
        }
        SpiQuery query = (SpiQuery)this.server.createQuery(beanType);
        query.setMode(SpiQuery.Mode.LAZYLOAD_BEAN);
        query.setPersistenceContext(persistenceContext);
        String mode = loadRequest.isLazy() ? "+lazy" : "+query";
        query.setLoadDescription(mode, loadRequest.getDescription());
        ctx.configureQuery(query, loadRequest.getLazyLoadProperty());
        query.setUseCache(false);
        if (idList.size() == 1) {
            query.where().idEq(idList.get(0));
        } else {
            query.where().idIn(idList);
        }
        List list = this.server.findList(query, loadRequest.getTransaction());
        if (desc.calculateUseCache(null)) {
            for (int i4 = 0; i4 < list.size(); ++i4) {
                desc.cachePutObject(list.get(i4));
            }
        }
    }

    public void refresh(Object bean) {
        this.refreshBeanInternal(bean, SpiQuery.Mode.REFRESH_BEAN);
    }

    public void loadBean(EntityBeanIntercept ebi) {
        this.refreshBeanInternal(ebi.getOwner(), SpiQuery.Mode.LAZYLOAD_BEAN);
    }

    private void refreshBeanInternal(Object bean, SpiQuery.Mode mode) {
        Object dbBean;
        boolean vanilla = !(bean instanceof EntityBean);
        EntityBeanIntercept ebi = null;
        PersistenceContext pc = null;
        if (!vanilla) {
            ebi = ((EntityBean)bean)._ebean_getIntercept();
            pc = ebi.getPersistenceContext();
        }
        BeanDescriptor desc = this.server.getBeanDescriptor(bean.getClass());
        Object id = desc.getId(bean);
        if (pc == null) {
            pc = new DefaultPersistenceContext();
            pc.put(id, bean);
            if (ebi != null) {
                ebi.setPersistenceContext(pc);
            }
        }
        SpiQuery query = (SpiQuery)this.server.createQuery(desc.getBeanType());
        if (ebi != null) {
            if (desc.refreshFromCache(ebi, id)) {
                return;
            }
            if (desc.lazyLoadMany(ebi)) {
                return;
            }
            Object parentBean = ebi.getParentBean();
            if (parentBean != null) {
                BeanDescriptor parentDesc = this.server.getBeanDescriptor(parentBean.getClass());
                Object parentId = parentDesc.getId(parentBean);
                pc.putIfAbsent(parentId, parentBean);
            }
            query.setLazyLoadProperty(ebi.getLazyLoadProperty());
        }
        query.setUsageProfiling(false);
        query.setPersistenceContext(pc);
        query.setMode(mode);
        query.setId(id);
        query.setUseCache(false);
        query.setVanillaMode(vanilla);
        if (ebi != null) {
            if (ebi.isSharedInstance()) {
                query.setSharedInstance();
            } else if (ebi.isReadOnly()) {
                query.setReadOnly(true);
            }
        }
        if ((dbBean = query.findUnique()) == null) {
            String msg = "Bean not found during lazy load or refresh. id[" + id + "] type[" + desc.getBeanType() + "]";
            throw new PersistenceException(msg);
        }
        if (desc.calculateUseCache(null) && !vanilla) {
            desc.cachePutObject(dbBean);
        }
    }
}

