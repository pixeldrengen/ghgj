/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.core;

import com.avaje.ebeaninternal.server.core.BootupClasses;
import com.avaje.ebeaninternal.server.util.ClassPathSearchMatcher;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class OnBootupClassSearchMatcher
implements ClassPathSearchMatcher {
    BootupClasses classes = new BootupClasses();

    @Override
    public boolean isMatch(Class<?> cls) {
        return this.classes.isMatch(cls);
    }

    public BootupClasses getOnBootupClasses() {
        return this.classes;
    }
}

