/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.core;

public class RefreshHelp {
}

