/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.core;

import com.avaje.ebeaninternal.server.core.RelationalQueryRequest;

public interface RelationalQueryEngine {
    public Object findMany(RelationalQueryRequest var1);
}

