/*
 * Decompiled with CFR 0_118.
 */
package com.avaje.ebeaninternal.server.core;

import com.avaje.ebean.BeanState;
import com.avaje.ebean.bean.EntityBean;
import com.avaje.ebean.bean.EntityBeanIntercept;
import java.beans.PropertyChangeListener;
import java.util.Collections;
import java.util.Set;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class DefaultBeanState
implements BeanState {
    final EntityBean entityBean;
    final EntityBeanIntercept intercept;

    public DefaultBeanState(EntityBean entityBean) {
        this.entityBean = entityBean;
        this.intercept = entityBean._ebean_getIntercept();
    }

    @Override
    public boolean isReference() {
        return this.intercept.isReference();
    }

    @Override
    public boolean isSharedInstance() {
        return this.intercept.isSharedInstance();
    }

    @Override
    public boolean isNew() {
        return this.intercept.isNew();
    }

    @Override
    public boolean isNewOrDirty() {
        return this.intercept.isNewOrDirty();
    }

    @Override
    public boolean isDirty() {
        return this.intercept.isDirty();
    }

    @Override
    public Set<String> getLoadedProps() {
        Set<String> props = this.intercept.getLoadedProps();
        return props == null ? null : Collections.unmodifiableSet(props);
    }

    @Override
    public Set<String> getChangedProps() {
        Set<String> props = this.intercept.getChangedProps();
        return props == null ? null : Collections.unmodifiableSet(props);
    }

    @Override
    public boolean isReadOnly() {
        return this.intercept.isReadOnly();
    }

    @Override
    public void setReadOnly(boolean readOnly) {
        this.intercept.setReadOnly(readOnly);
    }

    @Override
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        this.entityBean.addPropertyChangeListener(listener);
    }

    @Override
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        this.entityBean.removePropertyChangeListener(listener);
    }

    @Override
    public void setLoaded(Set<String> loadedProperties) {
        this.intercept.setLoadedProps(loadedProperties);
        this.intercept.setLoaded();
    }

    @Override
    public void setReference() {
        this.intercept.setReference();
    }
}

